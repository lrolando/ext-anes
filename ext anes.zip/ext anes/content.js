// Content script - fallback para Kiwi Browser cuando chrome.scripting no está disponible
// Escucha mensajes del popup y ejecuta el llenado del formulario

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'fillForm') {
    try {
      fillFormFromContentScript(message.data);
      sendResponse({ success: true });
    } catch (err) {
      sendResponse({ success: false, error: err.message });
    }
  }
  return true; // Mantener el canal abierto para respuesta asíncrona
});

function fillFormFromContentScript(data) {
  function setInputValue(input, value) {
    if (!input || !value) return;
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype, 'value'
    ).set;
    nativeInputValueSetter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
  }

  // 1) Click en "Nuevo"
  const btnNuevo = document.querySelector('#bNuevo button')
    || document.querySelector('jqxbutton#bNuevo button')
    || document.querySelector('[id="bNuevo"] button');

  if (btnNuevo) {
    btnNuevo.removeAttribute('disabled');
    btnNuevo.click();
  }

  // 2) Esperar a que el formulario se habilite y llenar campos
  setTimeout(() => {
    function findInputNear(searchText) {
      const elements = document.querySelectorAll('app-protocolo p, app-protocolo td, app-protocolo label, app-protocolo span, app-protocolo div');
      for (const el of elements) {
        const text = el.textContent.trim().toUpperCase();
        if (text.includes(searchText.toUpperCase())) {
          const parent = el.closest('td') || el.closest('tr') || el.closest('div');
          if (parent) {
            const input = parent.querySelector('input') || parent.nextElementSibling?.querySelector('input');
            if (input) return input;
          }
        }
      }
      return null;
    }

    const inputPaciente = findInputNear('Paciente');
    const inputObraSocial = findInputNear('Obrasocial') || findInputNear('Obra Social') || findInputNear('Obra social');
    const inputAfiliado = findInputNear('Afiliado');
    const inputFecha = findInputNear('Fecha');
    const inputLugar = findInputNear('Lugar');
    const inputCodigos = findInputNear('Busqueda') || findInputNear('Código') || findInputNear('Codigo');

    setInputValue(inputPaciente, data.Nombre);
    setInputValue(inputObraSocial, data.ObraSocial);
    setInputValue(inputAfiliado, data.NroAfiliado);
    setInputValue(inputLugar, data.Lugar);
    setInputValue(inputCodigos, data.Practicas);

    if (data.Fecha) {
      const fechaInput = inputFecha || document.querySelector('app-protocolo jqxdatetimeinput input');
      if (fechaInput) {
        setInputValue(fechaInput, data.Fecha);
      }
    }
  }, 800);
}

console.log('[Anestesia Extension] Content script cargado.');
