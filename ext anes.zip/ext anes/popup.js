const MAX_IMAGES = 7;
let images = []; // { file, dataUrl }

const fileInput = document.getElementById('fileInput');
const cameraInput = document.getElementById('cameraInput');
const btnSelect = document.getElementById('btnSelect');
const btnCamera = document.getElementById('btnCamera');
const previewsDiv = document.getElementById('previews');
const btnOCR = document.getElementById('btnOCR');
const btnFill = document.getElementById('btnFill');
const statusEl = document.getElementById('status');
const progressBar = document.getElementById('progressBar');
const progressFill = document.getElementById('progressFill');

// Campos
const fields = {
  Nombre: document.getElementById('fNombre'),
  ObraSocial: document.getElementById('fObraSocial'),
  NroAfiliado: document.getElementById('fNroAfiliado'),
  Practicas: document.getElementById('fPracticas'),
  Lugar: document.getElementById('fLugar'),
  Fecha: document.getElementById('fFecha'),
};

// ---- Carga de imágenes ----
btnSelect.addEventListener('click', () => fileInput.click());
btnCamera.addEventListener('click', () => cameraInput.click());

fileInput.addEventListener('change', () => {
  addFiles(fileInput.files);
  fileInput.value = '';
});

cameraInput.addEventListener('change', () => {
  addFiles(cameraInput.files);
  cameraInput.value = '';
});

function addFiles(fileList) {
  for (const file of fileList) {
    if (images.length >= MAX_IMAGES) {
      setStatus('Máximo 7 imágenes permitidas', 'error');
      break;
    }
    if (!file.type.startsWith('image/')) continue;
    const reader = new FileReader();
    reader.onload = (e) => {
      images.push({ file, dataUrl: e.target.result });
      renderPreviews();
      btnOCR.disabled = false;
    };
    reader.readAsDataURL(file);
  }
}

function renderPreviews() {
  previewsDiv.innerHTML = '';
  images.forEach((img, i) => {
    const div = document.createElement('div');
    div.className = 'preview-item' + (i === 0 ? ' active' : '');
    div.innerHTML = `
      <img src="${img.dataUrl}" alt="Img ${i + 1}">
      <div class="label">Foto ${i + 1}</div>
      <button class="remove" data-idx="${i}">&times;</button>
    `;
    previewsDiv.appendChild(div);
  });
  previewsDiv.querySelectorAll('.remove').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const idx = parseInt(btn.dataset.idx);
      images.splice(idx, 1);
      renderPreviews();
      if (images.length === 0) btnOCR.disabled = true;
    });
  });
}

// ---- OCR con Tesseract ----
btnOCR.addEventListener('click', async () => {
  if (images.length === 0) return;

  btnOCR.disabled = true;
  progressBar.style.display = 'block';
  progressFill.style.width = '0%';
  setStatus('Inicializando OCR...', '');

  try {
    const worker = await Tesseract.createWorker('spa', 1, {
      workerPath: chrome.runtime.getURL('tesseract/worker.min.js'),
      corePath: chrome.runtime.getURL('tesseract/tesseract-core-simd-lstm.wasm.js'),
      logger: (m) => {
        if (m.status === 'recognizing text') {
          const pct = Math.round(m.progress * 100);
          progressFill.style.width = pct + '%';
          setStatus(`Leyendo imagen... ${pct}%`, '');
        }
      },
    });

    const { data: { text } } = await worker.recognize(images[0].dataUrl);
    await worker.terminate();

    parseOCRText(text);

    progressFill.style.width = '100%';
    setStatus('OCR completado. Revisá los datos y corregí si es necesario.', 'success');
    btnFill.disabled = false;
  } catch (err) {
    console.error('Error OCR:', err);
    setStatus('Error en OCR: ' + err.message, 'error');
  } finally {
    btnOCR.disabled = false;
    setTimeout(() => { progressBar.style.display = 'none'; }, 2000);
  }
});

function parseOCRText(text) {
  console.log('Texto OCR completo:\n', text);
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

  const mapping = [
    { patterns: ['PACIENTE'], field: 'Nombre' },
    { patterns: ['OBRA SOCIAL', 'OBRA SOCIAL Y CODIGO'], field: 'ObraSocial' },
    { patterns: ['AFILIADO', 'N° AFILIADO', 'Nº AFILIADO', 'NO AFILIADO', 'N? AFILIADO'], field: 'NroAfiliado' },
    { patterns: ['CODIGO DE PRACTICA', 'CÓDIGO DE PRÁCTICA', 'CODIGO DE PRÁCTICA'], field: 'Practicas' },
    { patterns: ['LUGAR DE REALIZACION', 'LUGAR DE REALIZACIÓN'], field: 'Lugar' },
    { patterns: ['FECHA'], field: 'Fecha' },
  ];

  for (const line of lines) {
    const upper = line.toUpperCase();
    for (const map of mapping) {
      for (const pattern of map.patterns) {
        if (upper.includes(pattern)) {
          let value = '';
          const colonIdx = line.indexOf(':');
          if (colonIdx !== -1) {
            value = line.substring(colonIdx + 1).trim();
          }
          if (value || !fields[map.field].value) {
            fields[map.field].value = value;
          }
          break;
        }
      }
    }
  }
}

// ---- Enviar datos al formulario ----
btnFill.addEventListener('click', async () => {
  const data = {
    Nombre: fields.Nombre.value,
    ObraSocial: fields.ObraSocial.value,
    NroAfiliado: fields.NroAfiliado.value,
    Practicas: fields.Practicas.value,
    Lugar: fields.Lugar.value,
    Fecha: fields.Fecha.value,
    imagenes: images.map(img => img.dataUrl),
  };

  setStatus('Enviando datos al formulario...', '');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // Intentar con chrome.scripting (MV3 completo)
    if (chrome.scripting && chrome.scripting.executeScript) {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: fillForm,
        args: [data],
      });
      setStatus('Datos enviados al formulario.', 'success');
    } else {
      // Fallback: enviar mensaje al content script (Kiwi Browser)
      chrome.tabs.sendMessage(tab.id, { action: 'fillForm', data: data }, (response) => {
        if (chrome.runtime.lastError) {
          setStatus('Error: ' + chrome.runtime.lastError.message, 'error');
        } else {
          setStatus('Datos enviados al formulario.', 'success');
        }
      });
    }
  } catch (err) {
    console.error('Error al llenar formulario:', err);
    // Fallback adicional: intentar con tabs.sendMessage
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      chrome.tabs.sendMessage(tab.id, { action: 'fillForm', data: data }, (response) => {
        if (chrome.runtime.lastError) {
          setStatus('Error: ' + chrome.runtime.lastError.message, 'error');
        } else {
          setStatus('Datos enviados al formulario.', 'success');
        }
      });
    } catch (err2) {
      setStatus('Error: ' + err.message, 'error');
    }
  }
});

// Esta función se inyecta vía chrome.scripting.executeScript
function fillForm(data) {
  function setInputValue(input, value) {
    if (!input || !value) return;
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype, 'value'
    ).set;
    nativeInputValueSetter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
  }

  // 1) Click en "Nuevo"
  const btnNuevo = document.querySelector('#bNuevo button')
    || document.querySelector('jqxbutton#bNuevo button')
    || document.querySelector('[id="bNuevo"] button');

  if (btnNuevo) {
    btnNuevo.removeAttribute('disabled');
    btnNuevo.click();
  }

  // 2) Esperar a que el formulario se habilite y llenar campos
  setTimeout(() => {
    function findInputNear(searchText) {
      const elements = document.querySelectorAll('app-protocolo p, app-protocolo td, app-protocolo label, app-protocolo span, app-protocolo div');
      for (const el of elements) {
        const text = el.textContent.trim().toUpperCase();
        if (text.includes(searchText.toUpperCase())) {
          const parent = el.closest('td') || el.closest('tr') || el.closest('div');
          if (parent) {
            const input = parent.querySelector('input') || parent.nextElementSibling?.querySelector('input');
            if (input) return input;
          }
        }
      }
      return null;
    }

    const inputPaciente = findInputNear('Paciente');
    const inputObraSocial = findInputNear('Obrasocial') || findInputNear('Obra Social') || findInputNear('Obra social');
    const inputAfiliado = findInputNear('Afiliado');
    const inputFecha = findInputNear('Fecha');
    const inputLugar = findInputNear('Lugar');
    const inputCodigos = findInputNear('Busqueda') || findInputNear('Código') || findInputNear('Codigo');

    setInputValue(inputPaciente, data.Nombre);
    setInputValue(inputObraSocial, data.ObraSocial);
    setInputValue(inputAfiliado, data.NroAfiliado);
    setInputValue(inputLugar, data.Lugar);
    setInputValue(inputCodigos, data.Practicas);

    if (data.Fecha) {
      const fechaInput = inputFecha || document.querySelector('app-protocolo jqxdatetimeinput input');
      if (fechaInput) {
        setInputValue(fechaInput, data.Fecha);
      }
    }
  }, 800);
}

function setStatus(msg, type) {
  statusEl.textContent = msg;
  statusEl.className = 'status' + (type ? ' ' + type : '');
}
